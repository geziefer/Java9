#!/bin/bash -v

clear
if [ ! -n "$JAVA_HOME" ] ; then . ./prepair-Java9.sh ; fi
if [ ! -n "$JAVA_HOME" ] ; then echo -e "\nFehler: JAVA_HOME ist nicht definiert.\n" ; exit 1 ; fi

echo JAVA_HOME=$JAVA_HOME

java -version

javac -version

mvn clean package

java -p meineapp/target/de.meinefirma.meineapp-1.0.jar:meinutil/target/de.meinefirma.meinutil-1.0.jar -m de.meinefirma.meineapp/de.meinefirma.meineapp.MeineApp

