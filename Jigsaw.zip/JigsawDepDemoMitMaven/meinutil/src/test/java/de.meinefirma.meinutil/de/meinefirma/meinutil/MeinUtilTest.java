package de.meinefirma.meinutil;

import org.junit.*;

public class MeinUtilTest
{
   @Test
   public void testProcessInfos()
   {
      String s = MeinUtil.getProcessInfos();
      Assert.assertTrue( "pid:", s.contains( "pid:" ) );
      Assert.assertTrue( "user: Optional", s.contains( "user: Optional" ) );
      Assert.assertTrue( "cmd: Optional", s.contains( "cmd: Optional" ) );
      Assert.assertTrue( "java", s.contains( "java" ) );
   }
}
