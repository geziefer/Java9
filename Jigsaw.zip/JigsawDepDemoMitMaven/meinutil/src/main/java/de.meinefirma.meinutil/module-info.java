module de.meinefirma.meinutil
{
   exports de.meinefirma.meinutil;
}
