module de.meinefirma.meineapp
{
   requires de.meinefirma.meinutil;
}
