package de.meinefirma.meineapp;

import java.lang.ModuleLayer;
import de.meinefirma.meinutil.MeinUtil;

public class MeineApp
{
   public static void main( String[] args )
   {
      System.out.println( "CLASSPATH:           " + System.getProperty( "java.class.path" ) );
      System.out.println( "Class / Modul:       " + MeineApp.class.getSimpleName() + " aus " + MeineApp.class.getModule() +
                                             ", " + MeinUtil.class.getSimpleName() + " aus " + MeinUtil.class.getModule() );
      ModuleLayer lr = MeinUtil.class.getModule().getLayer();
      if( lr != null ) {
         System.out.println( "Layer.Configuration: " + lr.configuration() );
         System.out.println( "Layer.Modules:       " + lr.modules() );
      }
      System.out.println( "ProcessHandle-Infos: " + MeinUtil.getProcessInfos() );
   }
}
