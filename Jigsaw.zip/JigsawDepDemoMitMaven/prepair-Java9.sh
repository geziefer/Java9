
export JAVA_HOME=/usr/lib/jvm/java-9-oracle
export PATH=$JAVA_HOME/bin:$PATH

echo PATH=$PATH
echo JAVA_HOME=$JAVA_HOME
java -version
javac -version
