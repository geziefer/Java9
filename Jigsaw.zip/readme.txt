http://www.torsten-horn.de/techdocs/Jigsaw.html#Jigsaw-Dep-Demo-mit-Maven
